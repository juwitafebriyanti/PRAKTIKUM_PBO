/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uts;

/**
 *
 * @author afiii
 */
public class kalkulator {
    int angka1, angka2;
    
    void penjumlahan() {
        System.out.println(angka1 + angka2);
    }
 }
