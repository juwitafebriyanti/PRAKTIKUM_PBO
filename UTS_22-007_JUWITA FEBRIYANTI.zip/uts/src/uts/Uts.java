/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package uts;
import java.util.Scanner;
/**
 *
 * @author afiii
 */
class Uts extends kalkulator {
    Scanner input = new Scanner (System.in);
    
    void operasi() {
        System.out.println("Selamat Datang Di Kalkulator");
        
        kalkulator aa = new kalkulator();
        System.out.println("Masukkan angka1 : ");
        aa.angka1 = input.nextInt();
        System.out.println("Masukkan angka2 : ");
        aa.angka2 = input.nextInt();
    }
   
}
