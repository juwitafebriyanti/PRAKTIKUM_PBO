/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uts;
import java.util.Scanner;
/**
 *
 * @author afiii
 */
public class hemat {
    public static void main(String[] args) {
        Uts supc = new Uts();
        
        
        Scanner input = new Scanner(System.in);
        String pilihan = "1";
        
        while (pilihan=="1"){
            supc.operasi();
            
            
            System.out.print("\nIngin Mengulang Lagi ? (yes/no) : ");
            
            pilihan = input.nextLine();
                if (pilihan.startsWith("yes")){
                pilihan="1";
                System.out.println("\n\n\n");
            }else{
                System.out.println("\n===========================");
                System.out.println("         Terimakasih         ");
                System.out.println("      Telah Menggunakan      ");
                System.out.println("          Kalkulator          ");
                System.out.println("=============================");
                }
        }
    }
    
}
