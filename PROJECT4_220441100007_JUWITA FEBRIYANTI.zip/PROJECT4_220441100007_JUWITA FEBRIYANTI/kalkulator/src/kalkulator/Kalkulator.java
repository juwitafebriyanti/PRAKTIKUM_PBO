/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kalkulator;

/**
 *
 * @author afiii
 */

abstract class OperasiBilanganAbs {
     protected double a, b, c;
     
     protected abstract void set_A(double a);
     
     protected abstract void set_B(double b);
     
     protected abstract void set_C();
     
     protected abstract double get_A();
     
     protected abstract double get_B();
     
     protected abstract double get_C();
     
     protected abstract void tampil();    
}

class OperasiPenjumlahan extends OperasiBilanganAbs {
    protected void set_A(double a) {
        this.a=a;
    }
    
    protected void set_B(double b) {
        this.b=b;
    }
    
    protected void set_C() {
        this.c=a + b;
    }
    
    protected double get_A() {
        return a;
    }
    
    protected double get_B() {
        return b;
    }
    
    protected double get_C() {
        return c = a + b;
    }
    
    protected void tampil(){
        System.out.println("");
        System.out.println("====PENJUMLAHAN====");
        System.out.println("HASIL A+B = "+this.get_C());                                
    }
}

class OperasiPengurangan extends OperasiBilanganAbs {
    protected void set_A(double a){
        this.a = a;
    }
    
    protected void set_B(double b){
        this.b= b;
    }
    
    protected void set_C(){
        this.c = a - b;
    }
    
    protected double get_A(){
        return a;
    }
    
    protected double get_B(){
        return b;
    }
    
    protected double get_C(){
        return c = a - b;
    }
    
    protected void tampil(){
        System.out.println("");
        System.out.println("====PENGURANGAN====");
        System.out.println("HASIL A-B = "+this.get_C());      
    } 
}

class OperasiPerkalian extends OperasiBilanganAbs {

    protected void set_A(double a) {
        this.a=a;
    }
    
    protected void set_B(double b) {
        this.b=b;
    }
    
    protected void set_C() {
        this.c=a * b;
    }
    
    protected double get_A() {
        return a;
    }
    
    protected double get_B() {
        return b;
    }
    
    protected double get_C() {
        return c = a * b;
    }
     
    protected void tampil(){
        System.out.println("");
        System.out.println("====PERKALIAN====");
        System.out.println("HASIL A X B = "+this.get_C());                                           
    }
}

class OperasiPembagian extends OperasiBilanganAbs {
    protected void set_A(double a) {
        this.a=a;
    }
    
    protected void set_B(double b) {
        this.b=b;
    }
    
    protected void set_C() {
        this.c=a / b;
    }
    
    protected double get_A() {
        return a;
    }
    
    protected double get_B() {
        return b;
    }
    
    protected double get_C() {
        return c = a / b;
    }
    
    protected void tampil(){
        System.out.println("");
        System.out.println("====PEMBAGIAN====");
        System.out.println("HASIL A : B = "+this.get_C());                                          
    }
}
public final class Kalkulator {
    public static void main (String [] args){
        OperasiBilanganAbs[] a = new OperasiBilanganAbs [4];
        System.out.println("===================");
        System.out.println("OPERASI BILANGAN ARITMATIKA");
        System.out.println("");
        System.out.println("Bilangan A : 6.5");
        System.out.println("Bilangan B : 0.5");
         a[0] = new OperasiPenjumlahan();
         a[1] = new OperasiPengurangan();
         a[2] = new OperasiPerkalian();
         a[3] = new OperasiPembagian();
        
         for (OperasiBilanganAbs x : a){
             x.set_A(6.5);
             x.set_B(0.5);
             x.tampil();
        System.out.println("===================");
        }
    }
}

 
