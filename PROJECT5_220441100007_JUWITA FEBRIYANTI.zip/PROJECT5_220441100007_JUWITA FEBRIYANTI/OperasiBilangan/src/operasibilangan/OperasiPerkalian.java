/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operasibilangan;

/**
 *
 * @author afiii
 */
public class OperasiPerkalian extends OperasiBilangan {
     protected void set_A(double a) {
        this.a = a;
    }
    
    protected void set_B(double b) {
        this.b = b;
    }
    
    protected void set_C(double c) {
        this.c = c;
    }
    
    protected void set_D() {
        this.d = a * b * c;
    }
    
    protected double get_A() {
        return a;
    }
    
    protected double get_B() {
        return b;
    }
    
     protected double get_C() {
        return c;
    }
    
    protected double get_D() {
        return d = a * b * c;
    }
     
    protected void tampil(){
        System.out.println("");
        System.out.println("====PERKALIAN====");
        System.out.println("HASIL A X B X C = "+this.get_D());                                           
    }
}
