/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operasibilangan;

/**
 *
 * @author afiii
 */
public class OperasiBilanganCetak {
    public static void main (String [] args){
        OperasiBilangan[] a = new OperasiBilangan [4];
        System.out.println("===================");
        System.out.println("OPERASI BILANGAN ARITMATIKA");
        System.out.println("");
        System.out.println("Bilangan A : 10.5");
        System.out.println("Bilangan B : 0.5");
        System.out.println("Bilangan C : 1.25");
         a[0] = new OperasiPenjumlahan();
         a[1] = new OperasiPengurangan();
         a[2] = new OperasiPerkalian();
         a[3] = new OperasiPembagian();
        
         for (OperasiBilangan x : a){
             x.set_A(10.5);
             x.set_B(0.5);
             x.set_C(1.25);
             x.tampil();
        System.out.println("===================");
        }
    }
}
