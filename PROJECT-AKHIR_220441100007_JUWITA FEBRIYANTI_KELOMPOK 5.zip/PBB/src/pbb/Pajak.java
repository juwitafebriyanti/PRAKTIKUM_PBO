/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbb;

/**
 *
 * @author afiii
 */
abstract class Pajak implements Rumus{
    private String kode;
    private double luasTanah;
    private double nilaiTanah;
    private double luasBangunan;
    private double nilaiBangunan;

    public Pajak (String kode, double luasTanah, double nilaiTanah, double luasBangunan, double nilaiBangunan) {
        this.kode = kode;
        this.luasTanah = luasTanah;
        this.nilaiTanah = nilaiTanah;
         this.luasBangunan = luasBangunan;
        this.nilaiBangunan = nilaiBangunan;
    }
    
    public String getKode() {
        return kode;
    }

    public double getLuasTanah() {
        return luasTanah;
    }

    public double getNilaiTanah() {
        return nilaiTanah;
    }
    
    public double getLuasBangunan() {
        return luasBangunan;
    }

    public double getNilaiBangunan() {
        return nilaiBangunan;
    }


    public abstract double hitungNJOPBumi();
    public abstract double hitungNJOPBangunan();
    public abstract double hitungNJOP();
    public abstract double hitungNJKP();
}

