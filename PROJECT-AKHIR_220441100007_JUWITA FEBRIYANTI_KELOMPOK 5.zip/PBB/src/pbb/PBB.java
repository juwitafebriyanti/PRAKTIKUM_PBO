/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbb;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author afiii
 */


public class PBB {
    public static void main(String[] args) {
            Scanner input = new Scanner(System.in);
            String adminUsername = "Admin";
        String adminPassword = "Lima";
        System.out.println("============================================");
        System.out.println("                Program PBB ");
        

        System.out.println();

        // Login
        System.out.println("Silakan login");
        System.out.print("Username: ");
        String usernameInput = input.nextLine();
        System.out.print("Password: ");
        String passwordInput = input.nextLine();

        if (!usernameInput.equals(adminUsername) || !passwordInput.equals(adminPassword)) {
            System.out.println("Login gagal. Program akan keluar.");
            return;
        }

        System.out.println("Login berhasil!");
        System.out.println(" ");
        System.out.println("============================================");
        System.out.println(" ");
        
            Edit edit = new Edit();
            while (true) {
                System.out.println("=== Perhitungan Pajak Bumi dan Bangunan ===");
                System.out.println("1. Tambah Data");
                System.out.println("2. Tampilkan Daftar Data");
                System.out.println("3. Hapus Data");
                System.out.println("4. Keluar");
                System.out.print("Pilih Menu: ");
                int pilihan = input.nextInt();
                input.nextLine();
                System.out.println("===========================================");

                if (pilihan == 1) {
                    System.out.print("Masukkan Kode Data: ");
                    String kode = input.nextLine();
                    System.out.print("Masukkan Luas Tanah: ");
                    double luasTanah = input.nextDouble();
                    System.out.print("Masukkan Nilai Tanah: ");
                    double nilaiTanah = input.nextDouble();
                    input.nextLine();
                    System.out.print("Masukkan Luas Bangunan: ");
                    double luasBangunan = input.nextDouble();
                    System.out.print("Masukkan Nilai Bangunan: ");
                    double nilaiBangunan = input.nextDouble();
                    input.nextLine();
                    Bangunan bangunan = new Bangunan(kode, luasTanah, nilaiTanah, luasBangunan, nilaiBangunan);
                    edit.tambahData(bangunan);

                } else if (pilihan == 2) {
                    edit.tampilkanDaftarData();
                } else if (pilihan == 3) {
                    System.out.print("Masukkan Kode Data yang akan dihapus: ");
                    String kode = input.nextLine();
                    edit.hapusData(kode);
                } else if (pilihan == 4) {
                    System.out.println("Terima kasih!");
                    break;
                } else {
                    System.out.println("Pilihan tidak valid!");
                }
            }
        }
    }



