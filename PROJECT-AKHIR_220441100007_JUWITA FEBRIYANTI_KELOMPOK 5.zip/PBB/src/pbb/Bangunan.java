/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbb;

/**
 *
 * @author afiii
 */
class Bangunan extends Pajak {

    public Bangunan(String kode, double luasTanah, double nilaiTanah, double luasBangunan, double nilaiBangunan) {
        super(kode, luasTanah, nilaiTanah, luasBangunan, nilaiBangunan);
    }
   
     @Override
    public double hitungNJOPBumi() {
        return getLuasTanah() * getNilaiTanah();
    }

    @Override
    public double hitungNJOPBangunan() {
        return getLuasTanah() * getNilaiTanah();
    }

    @Override
    public double hitungNJOP() {
        return hitungNJOPBumi() + hitungNJOPBangunan() - 12000000;
    }
    
    @Override
    public double hitungNJKP() {
        return hitungNJOP() * 0.2;
    }
    
    
    @Override
    public double hitungPajak() {
        double njop = hitungNJOP();
        double njkp = hitungNJKP();
        double pajak = njkp * 0.005;
        return Math.max(0, pajak);
    }
}