/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbb;


import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author afiii
 */

class Edit {
    private List<Pajak> daftarPajak;

    public Edit() {
        daftarPajak = new ArrayList<>();
    }

    public void tambahData (Pajak data) {
        daftarPajak.add(data);
        System.out.println("Data berhasil ditambahkan.");
        System.out.println("-------------------------------------------");
        System.out.println(" ");
    }

    public void hapusData(String kode) {
        Pajak data= cariData(kode);
        if (data != null) {
            daftarPajak.remove(data);
            System.out.println("Data berhasil dihapus.");
            System.out.println("-------------------------------------------");
            System.out.println(" ");
        } else {
            System.out.println("Data tidak ditemukan.");
            System.out.println("-------------------------------------------");
            System.out.println(" ");
        }
    }

    public void tampilkanDaftarData() {
        if (daftarPajak.isEmpty()) {
            System.out.println("Tidak ada data yang tersedia.");
            System.out.println("-----------------------------------------------");
            System.out.println(" ");
        } else {
            System.out.println("Daftar Data:");
            for (Pajak data : daftarPajak) {
                System.out.println("-------------------------------------------");
                System.out.println("Kode: " + data.getKode());
                System.out.println("Luas Tanah: " + data.getLuasTanah());
                System.out.println("Nilai Tanah: " + data.getNilaiTanah());
                if (data instanceof Bangunan) {
                    Bangunan bangunan = (Bangunan) data;
                    System.out.println("Luas Bangunan: " + bangunan.getLuasBangunan());
                    System.out.println("Nilai Bangunan: " + bangunan.getNilaiBangunan());
                }
                System.out.println("-------------------------------------------");
                System.out.println("NJOP: " + data.hitungNJOP());
                System.out.println("NJKP: " + data.hitungNJKP());
                System.out.println("Pajak: " + data.hitungPajak());
                System.out.println("-------------------------------------------");
                System.out.println(" ");
            }
        }
    }

    public Pajak cariData(String kode) {
        for (Pajak data : daftarPajak) {
            if (data.getKode().equals(kode)) {
                return data;
            }
        }
        return null;
    }
}

