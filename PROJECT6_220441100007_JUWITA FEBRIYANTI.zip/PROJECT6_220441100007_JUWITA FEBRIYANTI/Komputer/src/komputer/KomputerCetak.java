/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komputer;

/**
 *
 * @author afiii
 */
final class KomputerCetak{
    final static void cetak(Komputer[]obj){
        obj[0] = new PC();
        obj[1] = new Laptop();
        obj[2] = new Netbook();
        
        for (int i = 0; i < obj.length; i++){
            System.out.println("----------------------------------");
            obj[i].hidupkan_os();
            obj[i].klik_kiri();
            obj[i].klik_kanan();
            obj[i].tekan_enter();
            obj[i].cetak_data();
            obj[i].matikan_os();
            System.out.println("----------------------------------");
            System.out.println("");
        }
    }
    public static void main(String[]args){
        Komputer[] com = new Komputer[3];
        cetak(com);
    }
}
