/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package komputer;

/**
 *
 * @author afiii
 */
abstract class Komputer implements Mouse, Keyboard, Printer {
    abstract void hidupkan_os();
    abstract void matikan_os();

}
