/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package datauniv;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author afiii
 */
public class DataUniv {
    private static String namaUniversitas;
    private String nim;
    private String nama;
    private String alamat;
    private String jurusan;
    
    public DataUniv(String nim, String nama, String alamat, String jurusan) {
        this.nim = nim;
        this.nama = nama;
        this.alamat = alamat;
        this.jurusan = jurusan;
        
    }
    
    public static void setNamaUniversitas(String namaUniversitas) {
        DataUniv.namaUniversitas = namaUniversitas;
    }
    
    public static String getNamaUniversitas() {
        return namaUniversitas;
    }
    
    public void setNim(String nim) {
        this.nim = nim;
    }
    
    public String getNim() {
        return nim;
    }
    
    public void setNama(String nama) {
        this.nama = nama;
    }
    
    public String getNama() {
        return nama;
    }
    
    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }
    
    public String getAlamat() {
        return alamat;
    }
    
    public void setJurusan(String jurusan) {
        this.jurusan = jurusan;
    }
    
    public String getJurusan() {
        return jurusan;
    }
   
    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        System.out.println("Masukkan Nama Universitas : ");
        String namauniversitas = input.nextLine();
        DataUniv.setNamaUniversitas(namauniversitas);
        ArrayList<DataUniv> daftarMahasiswa = new ArrayList<> ();
        char lagi;
        do {
            System.out.println("\n===== Masukkan Data Mahasiswa =====");
            System.out.println("Nama : ");
            String nama = input.nextLine();
            System.out.println("NIM : ");
            String nim = input.nextLine();
            System.out.println("Alamat : ");
            String alamat = input.nextLine();
            System.out.println("Pilihan Jurusan : ");
            System.out.println("41 = TEKNIK INFORMATIKA");
            System.out.println("42 = TEKNIK INDUSTRI");
            System.out.println("43 = TEKNIK ELETRO");
            System.out.println("44 = SISTEM INFORMASI");
            System.out.println("48 = TEKNIK MESIN");
            System.out.println("49 = TEKNIK MEKATRONIKA");
            System.out.println("Masukkan Pilihan Jurusan : ");
            int pilihan = input.nextInt();
            String jurusan;
            switch (pilihan) {
                case 41: 
                    jurusan = ("TEKNIK INFORMATIKA");
                    break;
                case 42: 
                    jurusan = ("TEKNIK INDUSTRI");
                    break;
                case 43: 
                    jurusan = ("TEKNIK ELEKTRO");
                    break;
                case 44: 
                    jurusan = ("SISTEM INFORMASI");
                    break;
                case 48: 
                    jurusan = ("TEKNIK MESIN");
                    break;
                case 49: 
                    jurusan = ("TEKNIK MEKATRONIKA");
                    break;
                default:
                    jurusan = ("Pilihan Jurusan Tidak Tersedia!!!");
            }
            
            DataUniv mahasiswa = new DataUniv (nim,nama,alamat,jurusan);
            daftarMahasiswa.add(mahasiswa);
            
            System.out.println("Apakah Anda ingin memasukkan data lagi? (Y/T) : ");
            lagi = input.next().charAt(0);
            input.nextLine();
            
            
        } while (lagi == 'Y' || lagi == 'y');
        
        System.out.println("\nDaftar Mahasiswa:");
        System.out.printf("%-40s%-20s%-40s%-20s\n", "NAMA", "NIM", "ALAMAT", "JURUSAN");
        for (DataUniv mahasiswa : daftarMahasiswa) {
        System.out.printf("%-40s%-20s%-40s%-20s\n", mahasiswa.getNama(), mahasiswa.getNim(), mahasiswa.getAlamat(), mahasiswa.getJurusan());
        }
    }
    
}
