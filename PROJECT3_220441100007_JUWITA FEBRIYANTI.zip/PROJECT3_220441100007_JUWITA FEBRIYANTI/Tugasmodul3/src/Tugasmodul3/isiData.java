/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugasmodul3;

import java.util.Scanner;

/**
 *
 * @author afiii
 */
    class isiData{
    Scanner input = new Scanner (System.in);
    Scanner input1 = new Scanner (System.in);
    
    void vcd(){
    System.out.println("==========================");
    System.out.println(" Selamat Datang           ");
    System.out.println("        Di                 ");
    System.out.println("    Perpustakaan          ");
    System.out.println("==========================");
    
    Data ss = new Data();
    System.out.print ("Masukkan judul buku : ");
    ss.nama = input.nextLine();
   
    System.out.print("Masukkan penulis buku : ");
    ss.penulis = input.nextLine();

    System.out.print ("Masukkan publiser buku : ");
    ss.publisher= input.nextLine();
    
    System.out.println ("==== Pilihan Kategori ====");
    System.out.println ("1. Semua Umur             ");
    System.out.println ("2. Dewasa                 ");
    System.out.println ("3. Remaja                 ");
    System.out.println ("4. Anak-Anak              ");
    System.out.println ("5. ??                     ");
    System.out.println ("========================= ");
    
    String pil1 ;
    int pil ;
    do{
            System.out.print ("Masukkan pilihan (angka) : ");
            pil = input1.nextInt();
            if (pil == 1){
                ss.kategori = "Semua Umur";
                pil1 = "y";
            }else if (pil == 2){
                ss.kategori = "Dewasa";
                pil1 = "y";
            }else if (pil == 3){
                ss.kategori = "Remaja";
                pil1 = "y";
            }else if (pil == 4){
                ss.kategori = "Anak-Anak";
                pil1 = "y";
            }else if (pil == 5){
                ss.kategori = "Tidak di ketahui";
                pil1 = "y";
            }else{
                System.out.println("Pilihan tidak ada, mohon masukan dengan benar !!! ");
                pil1 = "t";
            }
    }
    while (pil1 != "y");
    
    System.out.print("Masukan stok buku (angka): ");
    ss.stok = input1.nextInt();
    
    System.out.print("Masukan tahun terbit: ");
    ss.tahunTerbit = input1.nextInt();
    
    ss.Awalan();
    
    }
}


