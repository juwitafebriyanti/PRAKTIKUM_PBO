/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugasmodul3;

/**
 *
 * @author afiii
 */
class Data extends isiData {
    String nama, penulis,  publisher, kategori;
    int stok, tahunTerbit;
    String isiData;
    
    void Awalan (){
    System.out.println("\n=========================");
    System.out.println(" Buku ");
    System.out.println(" yang sedang di  ");
    System.out.println(" baca ");
    System.out.println("=========================");
    
    System.out.println("Judul Buku : "+this.nama);
    System.out.println("Aktor Buku : "+this.penulis);
    System.out.println("Publisher Buku : "+this.publisher);
    System.out.println("Kategori Buku : "+this.kategori);
    System.out.println("Stok Buku : "+this.stok);
    System.out.println("Tahun Terbit Buku : " + this.tahunTerbit);
    
    }
}


